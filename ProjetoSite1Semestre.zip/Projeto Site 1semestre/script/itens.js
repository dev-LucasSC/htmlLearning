function showInfo(material) {
    let info = "";
    switch (material) {
        case 'Papel':
            info = "O papel é um material reciclável comum e pode ser reciclado diversas vezes.";
            break;
        case 'Plástico':
            info = "Plástico pode ser reciclado em vários tipos de produtos, reduzindo a poluição.";
            break;
        case 'Vidro':
            info = "Vidro é infinitamente reciclável sem perda de qualidade.";
            break;
        case 'Metal':
            info = "Metais como alumínio e aço são altamente valorizados na reciclagem.";
            break;
        case 'Alumínio':
            info = "O alumínio é leve, durável e pode ser reciclado infinitamente sem perder qualidade.";
            break;
        case 'Cobre':
            info = "Cobre é um material altamente valorizado e amplamente reciclado devido à sua condutividade elétrica.";
            break;
        case 'Bateria':
            info = "Baterias contêm metais pesados e produtos químicos tóxicos, e sua reciclagem ajuda a prevenir a contaminação ambiental.";
            break;
        case 'Eletrônicos':
            info = "Eletrônicos recicláveis contêm componentes valiosos e materiais perigosos que precisam ser descartados corretamente.";
            break;
        default:
            info = "Informação não disponível.";
    }
    document.getElementById('info-container').innerText = info;
}