
document.addEventListener("DOMContentLoaded", function() {
    let pontos = 0; 
    const buttons = document.querySelectorAll('.botao');
    const pointsDisplay = document.getElementById('points');

    console.log('Botões encontrados:', buttons.length);

    buttons.forEach(function(button) {
        console.log('Adicionando evento ao botão');
        button.addEventListener('click', function() {
            pontos += 1;
            button.textContent = 'Resgatado!';
            pointsDisplay.textContent = pontos;
            button.disabled = true;
            console.log('Botão clicado, pontos:', pontos);
        });
    });
});
