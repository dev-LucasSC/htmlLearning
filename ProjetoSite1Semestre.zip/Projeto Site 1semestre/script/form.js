function saveToFile() {
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const cell = document.getElementById('cell').value;
    const aniversario = document.getElementById('aniversario').value;
    const interesse = document.getElementById('interesse').value;
    const disp = document.getElementById('disp').value;
    const msg = document.getElementById('msg').value;

    const data = `
Nome: ${nome}
Email: ${email}
Telefone: ${cell}
Data de Nascimento: ${aniversario}
Áreas de Interesse: ${interesse}
Disponibilidade: ${disp}
Mensagem: ${msg}
-----------------------------
`;

    const blob = new Blob([data], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = 'form_data.txt';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
}